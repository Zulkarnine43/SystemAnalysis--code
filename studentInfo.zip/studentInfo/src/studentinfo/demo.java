/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentinfo;

/**
 *
 * @author Shaon
 */
public class demo {
    
    
    
  public void studentInfo(){
        	 System.out.println("student_id : 163432601");
                 System.out.println("student_name : Zulkar Nine");
                 System.out.println("student_subject : B.sc. in CSE");
                 System.out.println("student_CGPA : 3.50");
            
        }
    
}
