/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentinfo;

/**
 *
 * @author Shaon
 */
public class student extends demo {
    
    public void registrationInfo(){
		 System.out.println("Registration_Date :06-07-2019");
                  System.out.println("Total_credit : 12");
		
	}
	public void subInfo(){
            System.out.println("Course_name : System Analysis and design");
             System.out.println("CouserTeacher_name : sakib khan");
		
	}
	public void attendenceInfo(){
		
                System.out.println("CouserTeacher_name : sakib khan");
	}
	public void ExamInfo(){
		
                System.out.println("Exam_Date : 26-08-2019");
	}
    
    
    
}
